Please find instructions at:
https://docs.google.com/document/d/1lHFWHP50jaYR6BXK2pzShCYYRpupHen5N16uLaRpgUk/edit?usp=drive_link

