Please find instructions at:
https://docs.google.com/document/d/1Z_kzd6qqqpnQ8vETRvpC3d6wJym3aHbZ4UpeF3pIdVs/edit?usp=drive_link

