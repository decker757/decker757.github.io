Please find instructions at:
https://docs.google.com/document/d/1OPOpZlbUfWea14t1WAV8RR0o88mxogd_t4N1uCJTyW8/edit?usp=sharing

